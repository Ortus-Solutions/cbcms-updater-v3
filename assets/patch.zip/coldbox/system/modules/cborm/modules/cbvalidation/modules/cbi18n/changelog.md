CHANGELOG
=========
## 1.2.0
* New configuration setting for logging when no translation is found `logUnknownTranslation`
* Adding Travis CI support

## 1.1.0
* Updated build process
* Updated docs and instructions

##1.0.2
* Fixes on `getRBKeys()` and `getRBString()` to load correct file paths.

##1.0.1
* production ignore lists
* Unloading of helpers

##1.0.0
* Create first module version