CHANGELOG
=========

## 1.1.0
* Travis integration
* DocBox updates
* Build process updates

## 1.0.0
* Create first module version