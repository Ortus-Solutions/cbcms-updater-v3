CHANGELOG
=========

## 2.0.0
* Updated internal markdown Java library to txtmark: https://github.com/rjeschke/txtmark

## 1.0.0
* Create first module version