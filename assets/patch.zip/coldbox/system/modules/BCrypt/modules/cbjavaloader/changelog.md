CHANGELOG
=========

## 1.1.0
* Travis Integration
* DocBox update
* Build updates
* CCM-17 Error handling broken in javaloader
* CCM-12 loadpaths setting doesn't allow directory
* Better documentation

## 1.0.0
* Create first module version