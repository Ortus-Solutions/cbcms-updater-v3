CHANGELOG
=========

## 1.2.0
* Travis integration
* DocBox updates
* Build process updates

## 1.1.0
* Updated build process
* Updated readme and instructions

##1.0.0
* Create first module version