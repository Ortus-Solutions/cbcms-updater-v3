CHANGELOG
=========

## 1.3.0
* Adobe CF Compatiblity

## 1.2.0
* Travis Updates	
* Changing the array of locations check so that it doesn't fail if a JAR file is passed in the array.
* Readme Updates
* ForgeBox2 Updates

## 1.1.0
* Travis Integration
* DocBox update
* Build updates
* CCM-17 Error handling broken in javaloader
* CCM-12 loadpaths setting doesn't allow directory
* Better documentation

## 1.0.0
* Create first module version