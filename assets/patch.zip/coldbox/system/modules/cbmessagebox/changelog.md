CHANGELOG
=========

## 2.0.0
* Updated build process to use new DocBox
* Updated build process to leverage CommandBox for dependencies
* Fixes missing template exception when modules directory is not in root
* Migrated to pure script
* Updated void functions to return MessageBox for chaining.
* Made default types changeable via prepend and append array methods
* Change all internal instance properties to accessible getter/setter properties. This will allow for overriding of all internal state variables

## 1.0.0
* Create first module version