CHANGELOG
=========

## 1.3.0
* Updated build process
* Travis integration
* JavaLoader dependencies updated
* DocBox udpates

## 1.2.0 
* Updated readme locations
* `Autoclean` property not respecting proper boolean value
* Updated build process to CommandBox

## 1.1.0
* Invalid slug id, so CommandBox was getting confused on installations
* Defaults for configuration setup differently to avoid collisions

## 1.0.0
* Create first module version