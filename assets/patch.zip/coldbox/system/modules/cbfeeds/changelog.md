CHANGELOG
=========

## 1.0.1
* Fixes for newer email addresses on regex checking of feed generation

##1.0.0
* Create first module version